<?php
 defined( '_JEXEC' ) or die;

 use Joomla\CMS\Factory;
 use Joomla\CMS\HTML\HTMLHelper;
 use Joomla\CMS\Uri\Uri;
  
 $app = Factory::getApplication();
 
 //get sitename for inclusion as alt in logo image
 $sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
 
 //get Web Asset Manager
 $wa = $this->getWebAssetManager();
 
 //preload the external Bootstrap javascript from getbootstrap.com
 //this resolves the DNS ahead of time
 $this->getPreloadManager()->dnsPrefetch('https://cdn.jsdelivr.net');
 
 //create the link for favicon in /media/site/templates/simple/images
 //true means look in the media folder, specifically our template
 //1 means return it as a tag ready to go
 $this->addHeadLink(HTMLHelper::_('image', 'favicon.png', '', [], true, 1), 'icon', 'rel', ['type' => 'image/png']);
 
 //did user paste in google fonts url in Settings-Site Template Styles-Simple Template in the Advanced Tab?
 //if so, the name of the language variable is googlefonts 
 $googlefonts = trim($this->params->get('googlefonts', '', 'string')); 
 
 //if it exists, follow directions given google fonts: 
 if($googlefonts !=='') {   
  $this->getPreloadManager()->preconnect('https://fonts.googleapis.com/', ['crossorigin' => 'anonymous']); 
  $this->getPreloadManager()->preconnect('https://fonts.gstatic.com/', ['crossorigin' => 'anonymous']); 
  $wa->registerAndUseStyle('googlefonts', $googlefonts, [], ['crossorigin' => 'anonymous'], []); 
 }
 
 //meta tag required for Bootstrap stylesheet
 $this->setMetaData('viewport', 'width=device-width, initial-scale=1');
 
 //check if a class was added to this menu item
 //the class will be applied to the body tag
 $menu = $app->getMenu()->getActive();
 $pageclass = $menu !== null ? $menu->getParams()->get('pageclass_sfx', '') : '';
 
 //prepare the img tag for the logo in the body section
 //true - search in media folder
 //0 - return it as an img tag
 //$sitename forms the alt tag
	$logo = HTMLHelper::_('image', 'logo.png', $sitename, ['class' => 'bannerlogo img-fluid', 'itemprop' => 'logo'], true, 0);
	
	//USE the scripts/styles in joomla.asset.json
	$wa->useStyle('template.style.simple')
		 ->useScript('template.script.simple');
 
	?>
	<!DOCTYPE html>
	 <html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	 <head>
		<jdoc:include type="metas" />
		<jdoc:include type="styles" />
		<jdoc:include type="scripts" />
	 </head>
	 <body class="site <?php echo empty($pageclass) ? '': $pageclass; ?>" id="top">
		<div class="container">
			<header>
				<div class="d-flex align-items-center">
					<a href="<?php echo Uri::base(); ?>"><?php echo $logo; ?></a>
					<h1><?php echo $sitename; ?></h1>
				</div>
			</header>
			<main>
				<div class="d-flex flex-column">
				  <jdoc:include type="message" />
					<jdoc:include type="component" />
				</div>
			</main>
			<footer>
				<!-- search module, first set up smart search in back end -->
			 <?php if ($this->countModules('search', true)) : ?>
				<div class="d-flex">  
				 <jdoc:include type="modules" name="search" style="none" />
				</div>
			 <?php endif; ?>
			 <!-- end search module -->
			</footer>
		</div>
 </body>
</html>
