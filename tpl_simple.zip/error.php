<?php
 defined( '_JEXEC' ) or die;
 
 use Joomla\CMS\Factory;
 use Joomla\CMS\HTML\HTMLHelper;
 //Use Uri to create home page link
 use Joomla\CMS\Uri\Uri; 
 //Use Text to parse language file strings or insert on the fly text
 use Joomla\CMS\Language\Text;

 $app = Factory::getApplication();
 $wa = $this->getWebAssetManager();

 //get sitename
 $sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
 
 //add the favicon
 $this->addHeadLink(HTMLHelper::_('image', 'favicon.png', '', [], true, 1), 'icon', 'rel', ['type' => 'image/png']);

 //google fonts - did user paste in google fonts url?
 $googlefonts = trim($this->params->get('googlefonts', '', 'string')); 
 //if so, preload scripts and register/use google fonts
 if($googlefonts !=='') {  
  $this->getPreloadManager()->preconnect('https://fonts.googleapis.com/', ['crossorigin' => 'anonymous']); 
  $this->getPreloadManager()->preconnect('https://fonts.gstatic.com/', ['crossorigin' => 'anonymous']); 
  $wa->registerAndUseStyle('googlefonts', $googlefonts, [], ['crossorigin' => 'anonymous'], []); 
 }

 //add a meta tag for the stylesheet
 $this->setMetaData('viewport', 'width=device-width, initial-scale=1');
 
 //generate the image tag for the error page
 //notice we use Text::_('error') to generate the text for the alt tag, since it's not in the language file
 $errorimg = HTMLHelper::_('image', 'error.jpg', Text::_('error'), ['class' => 'img-fluid shadow'], true, 0);

 //use the error stylesheet with Web Asset Manager
 $wa->useStyle('template.error.simple');
?>
 <!DOCTYPE html>
 <html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
 <head>
   <jdoc:include type="metas" />
   <jdoc:include type="styles" />
   <jdoc:include type="scripts" />
 </head>
 <body class="error">
  <div class="container">
   <div class="box-img">
    <!-- make a clickable image to home page -->
    <a itemprop="url" title="<?php echo $sitename; ?>" href="<?php echo Uri::base(); ?>">
     <?php echo $errorimg; ?>
    </a>
   </div>
   <div class="box-content">
    <div class="errtitle">
     <h1><?php echo $sitename; ?></h1>
     <h3><?php echo $this->error->getCode(); ?> - <?php echo Text::_('An error has occurred'); ?></h3>
     <p class="lead"><?php echo Text::_('Oops, this isn\'t right. Can we help?'); ?></p>
    </div>
    <div class="errbtn">
     <a href="<?php echo Uri::base(); ?>" class="btn">
      <?php echo Text::_('Find our Homepage here'); ?>
     </a>
    </div>
   </div>
  </div>
 </body>
</html>
