<?php
 defined( '_JEXEC' ) or die;
 
 use Joomla\CMS\Factory;
 use Joomla\CMS\HTML\HTMLHelper;

 $app = Factory::getApplication();
 $wa = $this->getWebAssetManager();

 //Perform DNS handshake for Bootstrap js files from CDN
 $this->getPreloadManager()->dnsPrefetch('https://cdn.jsdelivr.net');

 //get sitename
 $sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
 
 //add the favicon
 $this->addHeadLink(HTMLHelper::_('image', 'favicon.png', '', [], true, 1), 'icon', 'rel', ['type' => 'image/png']);

 //google fonts - did user paste in google fonts url?
 $googlefonts = trim($this->params->get('googlefonts', '', 'string')); 
 //if so, preload scripts and register/use google fonts
 if($googlefonts !=='') {  
  $this->getPreloadManager()->preconnect('https://fonts.googleapis.com/', ['crossorigin' => 'anonymous']); 
  $this->getPreloadManager()->preconnect('https://fonts.gstatic.com/', ['crossorigin' => 'anonymous']); 
  $wa->registerAndUseStyle('googlefonts', $googlefonts, [], ['crossorigin' => 'anonymous'], []); 
 }

 //add a meta tag for the stylesheet
 $this->setMetaData('viewport', 'width=device-width, initial-scale=1');

 //use the main stylesheet with Web Asset Manager
 $wa->useStyle('template.site.simple');
 //you might want to add a print css depending on your use case 
 //put it into /media/templates/site/simple/css
 //if you do, make sure it's in joomla.asset.json and uncomment next line
 //$wa->useStyle('template.print.simple');
 //use the external Bootstrap js from CDN
 $wa->useScript('bootstrapjs');
?>
 <!DOCTYPE html>
 <html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
 <head>
   <jdoc:include type="metas" />
   <jdoc:include type="styles" />
   <jdoc:include type="scripts" />
 </head>
 <body>
  <jdoc:include type="message" />
  <jdoc:include type="component" />
 </body>
</html>
